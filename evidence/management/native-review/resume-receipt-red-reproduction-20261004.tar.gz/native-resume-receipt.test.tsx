import { render, screen, within, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { expect, it } from 'vitest';
import { CommandProvider } from '/home/lucas/Developer/personal/cutokyo-community/ui/src/commands/context';
import { AnnouncementProvider } from '/home/lucas/Developer/personal/cutokyo-community/ui/src/components/Announcer';
import { SessionsPage } from '/home/lucas/Developer/personal/cutokyo-community/ui/src/pages/SessionsPage';
import { createBrowserFixtureClient } from '/home/lucas/Developer/personal/cutokyo-community/ui/src/fixtures/browserAdapter';
it('accepts the actual native acknowledged-launch warning receipt without encouraging another launch', async () => {
  const base = createBrowserFixtureClient('search-resume');
  // Exact response shape emitted by resume_session -> action_receipt('warning').
  const message = 'Claude Code started in a visible terminal with exact native ID claude-jev-73A9. Check that terminal for session activation or login errors; Cutokyo cannot verify native session activation.';
  render(<CommandProvider client={{ ...base, resumeSession: async () => ({ ok: false, status: 'warning', message }) }}><AnnouncementProvider><SessionsPage sessionId='session-claude-73A9' /></AnnouncementProvider></CommandProvider>);
  await userEvent.click(await screen.findByRole('button', {name: 'Resume'}));
  const dialog = await screen.findByRole('dialog');
  await userEvent.click(await within(dialog).findByRole('button', {name: 'Resume in Claude Code'}));
  await waitFor(() => expect(screen.queryByRole('dialog')).toBeNull());
  expect(screen.getByText(message, {selector: '.success-message p'})).toBeTruthy();
});
