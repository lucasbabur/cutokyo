import { render, screen, within, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { expect, it, vi } from 'vitest';
import { CommandProvider } from '/home/lucas/Developer/personal/cutokyo-community/ui/src/commands/context';
import { AnnouncementProvider } from '/home/lucas/Developer/personal/cutokyo-community/ui/src/components/Announcer';
import { SessionsPage } from '/home/lucas/Developer/personal/cutokyo-community/ui/src/pages/SessionsPage';
import { createBrowserFixtureClient } from '/home/lucas/Developer/personal/cutokyo-community/ui/src/fixtures/browserAdapter';

it('accepts the corrected native acknowledged-launch warning without offering a duplicate launch', async () => {
  const base = createBrowserFixtureClient('search-resume');
  // Corrected explicit receipt from service.rs resume_session after harness_started.
  // The separate original ok:false reproduction is preserved unchanged as red evidence.
  const message = 'Claude Code started in a visible terminal with exact native ID claude-jev-73A9. Check that terminal for session activation or login errors; Cutokyo cannot verify native session activation.';
  const resumeSession = vi.fn(async () => ({ ok: true, status: 'warning' as const, message }));
  render(<CommandProvider client={{ ...base, resumeSession }}><AnnouncementProvider><SessionsPage sessionId='session-claude-73A9' /></AnnouncementProvider></CommandProvider>);
  const user = userEvent.setup();
  const trigger = await screen.findByRole('button', { name: 'Resume' });
  await user.click(trigger);
  const dialog = await screen.findByRole('dialog');
  await user.click(await within(dialog).findByRole('button', { name: 'Resume in Claude Code' }));
  await waitFor(() => expect(screen.queryByRole('dialog')).toBeNull());
  expect(screen.getByText(message, { selector: '.success-message p' })).toBeTruthy();
  expect(screen.queryByRole('alert')).toBeNull();
  const statuses = screen.getAllByRole('status');
  expect(statuses).toHaveLength(2);
  expect(statuses.find((node) => node.classList.contains('success-message'))?.textContent).toBe(message);
  await waitFor(() => expect(statuses.find((node) => node.classList.contains('sr-only'))?.textContent).toBe(message));
  expect(document.activeElement).toBe(trigger);
  expect(resumeSession).toHaveBeenCalledTimes(1);
  expect(resumeSession).toHaveBeenCalledWith('session-claude-73A9');
});
