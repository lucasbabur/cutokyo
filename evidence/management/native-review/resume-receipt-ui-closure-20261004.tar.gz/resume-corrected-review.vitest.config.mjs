import base from '/home/lucas/Developer/personal/cutokyo-community/ui/vitest.config.ts';
export default {
  ...base,
  root: '/home/lucas/Developer/personal/cutokyo-community/ui',
  test: {
    ...base.test,
    include: ['/tmp/cutokyo-search-review.HJ6CZt/native-resume-receipt-corrected.test.tsx'],
    setupFiles: ['/home/lucas/Developer/personal/cutokyo-community/ui/src/test/setup.ts'],
  },
};
