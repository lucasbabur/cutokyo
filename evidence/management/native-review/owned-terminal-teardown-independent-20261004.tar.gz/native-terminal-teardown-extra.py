"""Independent mock-only postcondition/refusal checks; no native launch/signals."""
import copy
import importlib.util
from pathlib import Path
import unittest
from unittest.mock import patch

SOURCE = Path('/home/lucas/Developer/personal/cutokyo-community/ui/scripts/test_native_e2e.py')
spec = importlib.util.spec_from_file_location('reviewed_teardown_tests', SOURCE)
if spec is None or spec.loader is None:
    raise RuntimeError('Reviewed mock teardown tests could not be loaded')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
NATIVE = module.NATIVE

class IndependentTeardown(unittest.TestCase):
    def setUp(self):
        self.fixture = module.NativeResumeTerminalTeardown()
        self.fixture.setUp()
        self.addCleanup(self.fixture.doCleanups)

    def refusal_before_handle(self, mutation):
        f = self.fixture
        proof = f.proof()
        mutation()
        with self.assertRaises((RuntimeError, FileNotFoundError)):
            NATIVE.cleanup_resume_terminal(f.project, f.native_id, proof, f.env)
        f.open_pidfd.assert_not_called()
        f.signal.assert_not_called()

    def test_changed_exact_argv_or_context_audits_refuse(self):
        f = self.fixture
        self.refusal_before_handle(lambda: (f.root / 'resume-audit.txt').write_text('--resume\nwrong-id\n'))
        (f.root / 'resume-audit.txt').write_text(f'--resume\n{f.native_id}\n')
        self.refusal_before_handle(lambda: (f.root / 'resume-audit.context.json').write_text('{"cwd":"/foreign","stdinTty":true,"stdoutTty":true}'))

    def test_receiver_symlink_refuses(self):
        f = self.fixture
        receiver = f.root / 'bin/cutokyo'
        def mutate():
            saved = f.root / 'bin/other'
            receiver.rename(saved)
            receiver.symlink_to(saved)
        self.refusal_before_handle(mutate)

    def test_app_start_identity_changed_after_pidfd_refuses(self):
        f = self.fixture
        proof = f.proof()
        def mutate(_pid):
            f.processes[1]['start'] += 1
            return 99
        f.open_pidfd.side_effect = mutate
        with self.assertRaisesRegex(RuntimeError, 'identity changed'):
            NATIVE.cleanup_resume_terminal(f.project, f.native_id, proof, f.env)
        f.signal.assert_not_called()
        f.close_pidfd.assert_called_once_with(99)

    def test_app_disappearing_after_signal_is_not_success(self):
        f = self.fixture
        proof = f.proof()
        def processes():
            return [] if f.stopped else copy.deepcopy(f.processes)
        with patch.object(NATIVE, 'resume_processes', side_effect=processes):
            with self.assertRaisesRegex(RuntimeError, 'application identity changed'):
                NATIVE.cleanup_resume_terminal(f.project, f.native_id, proof, f.env)
        f.signal.assert_called_once_with(99, NATIVE.signal.SIGTERM)

    def test_owned_descendant_surviving_is_not_success(self):
        f = self.fixture
        proof = f.proof()
        def processes():
            return copy.deepcopy(f.processes[:2] + [f.processes[3]] if f.stopped else f.processes)
        with patch.object(NATIVE, 'resume_processes', side_effect=processes), patch.object(NATIVE.time, 'monotonic', side_effect=[0, 6]):
            with self.assertRaisesRegex(RuntimeError, 'descendants/window survived'):
                NATIVE.cleanup_resume_terminal(f.project, f.native_id, proof, f.env)
        f.signal.assert_called_once_with(99, NATIVE.signal.SIGTERM)

    def test_owned_window_surviving_is_not_success(self):
        f = self.fixture
        proof = f.proof()
        def compositor(_env, query):
            return copy.deepcopy(f.clients if query == 'clients' else f.active)
        with patch.object(NATIVE, 'resume_compositor', side_effect=compositor), patch.object(NATIVE.time, 'monotonic', side_effect=[0, 6]):
            with self.assertRaisesRegex(RuntimeError, 'descendants/window survived'):
                NATIVE.cleanup_resume_terminal(f.project, f.native_id, proof, f.env)
        f.signal.assert_called_once_with(99, NATIVE.signal.SIGTERM)

    def test_live_helper_below_held_child_is_pending(self):
        f = self.fixture
        f.processes.append({'pid': 45, 'parent': 32, 'group': 32, 'start': 5, 'exe': str(f.root / 'bin/cutokyo'), 'argv': [str(f.root / 'bin/cutokyo')]})
        f.environments[45] = f.env.copy()
        proof = f.proof()
        self.assertFalse(proof['ready'])
        with self.assertRaisesRegex(RuntimeError, 'unfinished'):
            NATIVE.cleanup_resume_terminal(f.project, f.native_id, proof, f.env)
        f.open_pidfd.assert_not_called()
        f.signal.assert_not_called()

    def test_malformed_expected_receipt_refuses(self):
        f = self.fixture
        for expected in ({}, {'ready': True}, None, [], {'ready': True, 'terminal': {'pid': 30}}):
            with self.subTest(expected=expected), self.assertRaisesRegex(RuntimeError, 'stale identity'):
                NATIVE.cleanup_resume_terminal(f.project, f.native_id, expected, f.env)
        f.open_pidfd.assert_not_called()
        f.signal.assert_not_called()

if __name__ == '__main__':
    unittest.main(verbosity=2)
