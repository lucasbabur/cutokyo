import pathlib,subprocess,json,sys,os
base=pathlib.Path('/tmp/cutokyo-independent-onboarding-review/opencode-safety-'+sys.argv[1]);base.mkdir(exist_ok=True)
cli='/home/lucas/Developer/personal/cutokyo-community/target/debug/cutokyo';node=subprocess.check_output(['node','-p','process.execPath'],text=True).strip()
for case in ['spool-link','tmp-link','quarantine-link','data-link','wide-spool']:
 root=base/case;root.mkdir(exist_ok=True);(root/'bin').mkdir(exist_ok=True);p=root/'bin/opencode';p.write_text('#!/usr/bin/python3\nprint("1.18.28")\n');p.chmod(0o700);(root/'bin/cutokyo').symlink_to(cli)
 env={'HOME':str(root/'home'),'XDG_CONFIG_HOME':str(root/'config'),'XDG_DATA_HOME':str(root/'xdg-data'),'PATH':str(root/'bin')}
 data=root/'private-data';cmd=[cli,'--config-file',str(root/'config.toml'),'--data-dir',str(data),'--json']
 r=subprocess.run(cmd+['capture-setup','--harness','opencode'],env=env,capture_output=True,text=True,timeout=15);print(json.dumps({'case':case,'setup_exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr}),flush=True)
 if r.returncode:continue
 target=root/'unrelated-destination';target.mkdir(mode=0o755)
 spool=data/'spool'
 if case=='data-link':data.rename(root/'old-data');data.symlink_to(target)
 elif case=='spool-link':spool.symlink_to(target)
 else:
  spool.mkdir(mode=0o755)
  if case=='tmp-link':(spool/'.tmp').symlink_to(target)
  elif case=='quarantine-link':(spool/'quarantine').symlink_to(target)
 plugin=root/'config/opencode/plugins/cutokyo.ts'
 event={'id':'private-native-'+case,'type':'session.created','properties':{'sessionID':'ses_safety_exact','info':{'id':'ses_safety_exact','directory':str(root/'private-project'),'title':'PRIVATE_NATIVE_SENTINEL','version':'1.18.28','time':{'created':1791072000000,'updated':1791072000000}}}}
 mjs=root/'invoke.mjs';mjs.write_text('import {Cutokyo} from '+json.dumps(plugin.as_uri())+';const p=await Cutokyo({});p.event({event:'+json.dumps(event)+'});\n')
 r=subprocess.run([node,str(mjs)],env=env,capture_output=True,text=True,timeout=10)
 print(json.dumps({'case':case,'node_exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'unexpected_entries':[str(p.relative_to(target)) for p in target.rglob('*')],'db_before_drain':(data/'cutokyo.db').exists(),'spool_mode':oct(spool.stat().st_mode&0o777) if spool.exists() else None,'spool_entries':[str(p) for p in spool.glob('*.jsonl')] if spool.exists() else []}),flush=True)
