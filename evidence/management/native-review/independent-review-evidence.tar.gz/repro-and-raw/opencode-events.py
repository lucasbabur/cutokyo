import pathlib,subprocess,json,sys,shutil
root=pathlib.Path('/tmp/cutokyo-independent-onboarding-review/opencode-events-'+sys.argv[1]);root.mkdir(exist_ok=True)
cli='/home/lucas/Developer/personal/cutokyo-community/target/debug/cutokyo';node=subprocess.check_output(['node','-p','process.execPath'],text=True).strip()
(root/'bin').mkdir(exist_ok=True);(root/'project').mkdir(exist_ok=True)
p=root/'bin/opencode';p.write_text('#!/usr/bin/python3\nprint("1.18.28")\n');p.chmod(0o700);(root/'bin/cutokyo').symlink_to(cli)
env={'HOME':str(root/'home'),'XDG_CONFIG_HOME':str(root/'config'),'XDG_DATA_HOME':str(root/'xdg-data'),'PATH':str(root/'bin')}
cmd=[cli,'--config-file',str(root/'config.toml'),'--data-dir',str(root/'data'),'--json']
def call(args):
 r=subprocess.run(cmd+args,env=env,capture_output=True,text=True,timeout=15);print(json.dumps({'args':args,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr}),flush=True)
call(['capture-setup','--harness','opencode'])
plugin=root/'config/opencode/plugins/cutokyo.ts'
events=[
 {'id':'created-exact','type':'session.created','properties':{'sessionID':'ses_exact_review','info':{'id':'ses_exact_review','projectID':'native-project','directory':str(root/'project'),'title':'real-shaped session','version':'1.18.28','time':{'created':1791072000000,'updated':1791072000000}}}},
 {'id':'part-exact','type':'message.part.updated','properties':{'part':{'id':'part_review_1','sessionID':'ses_exact_review','messageID':'msg_review_1','type':'text','text':'OPENCODE_MESSAGE_TEXT_NEEDLE','time':{'start':1791072000000}}}},
 {'type':'server.connected','properties':{}},
 {'type':'new_unknown_event','data':'not an observed native generation','properties':None,'syncEvent':{'data':{'sessionID':'ses_unknown_shape'}}}
]
mjs=root/'invoke.mjs';mjs.write_text('import {Cutokyo} from '+json.dumps(plugin.as_uri())+';const p=await Cutokyo({});for(const event of '+json.dumps(events)+')p.event({event});\n')
r=subprocess.run([node,str(mjs)],env=env,capture_output=True,text=True,timeout=10);print(json.dumps({'node_exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr}),flush=True)
print(json.dumps({'db_before_drain':(root/'data/cutokyo.db').exists(),'entries':[json.loads(p.read_text()) for p in (root/'data/spool').glob('*.jsonl')]}),flush=True)
for args in [['drain'],['sessions','list'],['sessions','search','--query','OPENCODE_MESSAGE_TEXT_NEEDLE'],['sessions','resume','ses_unknown_shape'],['sessions','resume','opencode:global']]:call(args)
