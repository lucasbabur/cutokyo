use std::{fs, path::PathBuf};
use cutokyo_core::app::{Application, CaptureSetupOperation as Op, CaptureSetupSpec, InventoryRoots, ResumePlan};
use cutokyo_domain::Harness;
fn main() -> Result<(), Box<dyn std::error::Error>> {
 let app = Application::new();
 let mode = std::env::args().nth(1).unwrap_or("setup".into());
 let base = PathBuf::from(std::env::args().nth(2).unwrap_or("/tmp/cutokyo-independent-onboarding-review/run".into()));
 fs::create_dir_all(&base)?;
 if mode == "resume" {
   let harness = std::env::args().nth(3).unwrap_or("claude_code".into());
   let (exec, flag) = match harness.as_str() {"codex" => ("codex", "resume"), "opencode" => ("opencode", "--session"), _ => ("claude", "--resume")};
   let project = base.join("project ' ; touch SHOULD_NOT_EXIST"); fs::create_dir_all(&project)?;
   let paths = app.runtime_paths(Some(base.join("config.toml")), Some(base.join("data")))?; fs::create_dir_all(&paths.data_dir)?;
   let id = "native:exact/123";
   let plan = ResumePlan{ session_id:"cutokyo:test".into(), harness, native_resume_id:id.into(), executable:exec.into(), arguments:vec![flag.into(),id.into()], working_directory:Some(project)};
   let receiver = PathBuf::from(std::env::var("REVIEW_RECEIVER")?);
   println!("preview={:?}", app.preview_terminal_resume(&plan,&receiver));
   println!("launch={:?}", app.launch_terminal_resume(&paths,&plan,&receiver));
   return Ok(());
 }
 for (name, h, version) in [("claude", Harness::ClaudeCode,"2.1.278"),("codex",Harness::Codex,"0.153.4"),("opencode",Harness::OpenCode,"1.18.28")] {
   let root = base.join(name); fs::create_dir_all(&root)?;
   let roots = InventoryRoots{home:root.join("home"),claude:root.join("native/claude"),codex:root.join("native/codex"),opencode:root.join("native/opencode"),opencode_config:None,opencode_global:None,projects:vec![]};
   let paths = app.runtime_paths(Some(root.join("config.toml")),Some(root.join("private-data")))?;
   let receiver = root.join("receiver"); fs::write(&receiver,"#!/bin/sh\nexit 0\n")?;
   use std::os::unix::fs::PermissionsExt;
   fs::set_permissions(&receiver,fs::Permissions::from_mode(0o700))?;
   let native_executable=root.join("fake-native");fs::write(&native_executable,"#!/bin/sh\nexit 0\n")?;fs::set_permissions(&native_executable,fs::Permissions::from_mode(0o700))?;
   let spec = CaptureSetupSpec{ roots:roots.clone(),paths:paths.clone(),receiver:receiver.clone(),native_executable:native_executable.clone(),version:version.into(),harness:h };
   let native = match h {Harness::ClaudeCode => roots.claude.join("settings.json"),Harness::Codex => roots.codex.join("hooks.json"),Harness::OpenCode => roots.opencode.join("opencode.json")};
   fs::create_dir_all(native.parent().ok_or("missing parent")?)?;
   let original = b"{  \"user-only\"  : \"KEEP THIS BYTE LAYOUT\", \"hooks\": {} }\n"; fs::write(&native,original)?;
   let p=app.preview_capture_setup(spec.clone(),Op::Install)?;
   println!("{name} preview={}",serde_json::to_string(&p.preview)?);
   fs::write(&receiver,"receiver-AFTER-CHANGED")?;
   println!("{name} receiver_changed_execute={:?}",app.execute_capture_setup(&p));
   let p=app.preview_capture_setup(spec.clone(),Op::Install)?;
   println!("{name} idempotent={:?}",app.execute_capture_setup(&p));
   println!("{name} unmanaged_field_bytes_preserved={}",fs::read(&native)?.windows(b"\"user-only\"  : \"KEEP THIS BYTE LAYOUT\"".len()).any(|w|w == b"\"user-only\"  : \"KEEP THIS BYTE LAYOUT\""));
   if mode == "install-only" {continue;}
   if matches!(mode.as_str(), "drift" | "drift-bytes") && name == "codex" {
     if mode == "drift-bytes" {
       let text=fs::read_to_string(&native)?;
       fs::write(&native,text.replacen("\"command\"", "\"review_user_edit\" : true, \"command\"",1))?;
     } else {
       let mut json:serde_json::Value=serde_json::from_slice(&fs::read(&native)?)?;
       let hooks=json["hooks"].as_object_mut().ok_or("no hooks")?;
       let first=hooks.values_mut().find_map(|v|v.as_array_mut().and_then(|v|v.first_mut())).ok_or("no hook entry")?;
       first["review_user_edit"]=true.into();
       fs::write(&native,serde_json::to_vec_pretty(&json)?)?;
     }
     match app.preview_capture_setup(spec.clone(),Op::Uninstall) {
       Err(e)=>println!("codex edited_owned_uninstall_preview=Err({e:?})"),
       Ok(plan)=>{
         println!("codex edited_owned_uninstall_preview={:?}",plan.preview);
         println!("codex edited_owned_uninstall_execute={:?}",app.execute_capture_setup(&plan));
         let remaining:serde_json::Value=serde_json::from_slice(&fs::read(&native)?)?;
         println!("codex edited_owned_remaining={remaining}");
         println!("codex partial_cleanup_unmanaged_bytes_preserved={}",fs::read_to_string(&native)?.contains("\"user-only\"  : \"KEEP THIS BYTE LAYOUT\""));
         println!("codex edited_owned_repeat={:?}",app.preview_capture_setup(spec.clone(),Op::Uninstall).and_then(|p|app.execute_capture_setup(&p)));
       }
     }
     continue;
   }
   let p=app.preview_capture_setup(spec.clone(),Op::Uninstall)?;
   println!("{name} uninstall={:?}",app.execute_capture_setup(&p));
   println!("{name} restored_bytes={}",fs::read(&native)? == original);
   let p=app.preview_capture_setup(spec.clone(),Op::Install)?;
   fs::write(&native,b"{\"user-only\":\"EDIT AFTER PREVIEW\",\"hooks\":{}}\n")?;
   println!("{name} stale_native={:?}",app.execute_capture_setup(&p));
 }
 Ok(())
}
