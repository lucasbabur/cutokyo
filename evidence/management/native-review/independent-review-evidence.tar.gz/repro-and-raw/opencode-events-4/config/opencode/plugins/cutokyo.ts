// cutokyo-owned: opencode-plugin-v1
import { spawnSync } from "node:child_process"

function spoolRoot(): string { return "/tmp/cutokyo-independent-onboarding-review/opencode-events-4/data/spool"; }
function writeStatus(_root: string, _category: string): void {
  console.error("Cutokyo native capture unavailable; OpenCode may continue.")
}
function capture(event: Record<string, any>, serverUrl: string | undefined, pluginApi: "v1" | "v2"): void {
  const input = JSON.stringify({ event, server_url: serverUrl, plugin_api: pluginApi })
  if (Buffer.byteLength(input, "utf8") > 8 * 1024 * 1024) { writeStatus(spoolRoot(), "entry_bytes"); return }
  // argv/stdin, not shell interpolation. Rust owns private atomic spool publication.
  const result = spawnSync("/home/lucas/Developer/personal/cutokyo-community/target/debug/cutokyo", ["--data-dir","/tmp/cutokyo-independent-onboarding-review/opencode-events-4/data","native-hook","--harness","opencode","--version","1.18.28"], { input, timeout: 3000, stdio: ["pipe", "ignore", "inherit"] })
  if (result.error || result.status !== 0) writeStatus(spoolRoot(), "receiver_unavailable")
}
export const Cutokyo = async ({ serverUrl }: { serverUrl?: URL }) => ({
  event: ({ event }: { event: Record<string, any> }) => {
    try {
      capture(event, serverUrl?.toString(), "v1")
    } catch {
      try { writeStatus(spoolRoot(), "capture_failed") } catch {}
    }
  },
})
