import pathlib,subprocess,os,json,shutil,sys,time
base=pathlib.Path('/tmp/cutokyo-independent-onboarding-review/native-smoke-'+(sys.argv[1] if len(sys.argv)>1 else '1'));base.mkdir(parents=True,exist_ok=True)
cli='/home/lucas/Developer/personal/cutokyo-community/target/debug/cutokyo';node=subprocess.check_output(['node','-p','process.execPath'],text=True).strip()
for h,version in [('claude_code','2.1.278'),('opencode','1.18.28'),('codex','0.153.4')]:
 root=base/h
 for p in ['home','bin','project exact native']:(root/p).mkdir(parents=True,exist_ok=True)
 env={'HOME':str(root/'home'),'PATH':str(root/'bin'),'XDG_CONFIG_HOME':str(root/'config'),'XDG_DATA_HOME':str(root/'xdg-data'),'XDG_STATE_HOME':str(root/'xdg-state'),'CLAUDE_CONFIG_DIR':str(root/'home/.claude'),'CODEX_HOME':str(root/'home/.codex'),'DISPLAY':':FAKE_ONLY','REVIEW_TERMINAL_AUDIT':str(root/'terminal-audit.json'),'REVIEW_HARNESS_AUDIT':str(root/'harness-audit.json')}
 receiver=root/'bin/cutokyo'
 if not receiver.exists():receiver.symlink_to(cli)
 harness_name={'claude_code':'claude','opencode':'opencode','codex':'codex'}[h]
 p=root/'bin'/harness_name;p.write_text('#!/usr/bin/python3\nimport os,json,sys,time\nif sys.argv[1:]==["--version"]:print("'+version+'");sys.exit(0)\nopen(os.environ["REVIEW_HARNESS_AUDIT"],"w").write(json.dumps({"argv":sys.argv[1:],"cwd":os.getcwd(),"ttyin":os.isatty(0),"ttyout":os.isatty(1)}))\ntime.sleep(1)\n');p.chmod(0o700)
 shutil.copy2('/tmp/cutokyo-independent-onboarding-review/terminal-fixtures/bin/kitty',root/'bin/kitty')
 cmd=[cli,'--config-file',str(root/'config.toml'),'--data-dir',str(root/'cutokyo-data'),'--json']
 outputs=[]
 def call(args,stdin=None):
  r=subprocess.run(cmd+args,env=env,input=stdin,capture_output=True,text=True,timeout=16)
  out={'command':cmd+args,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr};outputs.append(out);print(h,json.dumps(out),flush=True)
  try:return json.loads(r.stdout)
  except:return None
 call(['capture-setup','--harness',h,'--dry-run'])
 call(['capture-setup','--harness',h])
 project=str(root/'project exact native');needle='NATIVE_SEARCH_NEEDLE_'+h.upper();sid='native_'+h+'_exact'
 if h=='claude_code':
  transcript=root/'home/.claude/projects/synthetic-project'/f'{sid}.jsonl';transcript.parent.mkdir(parents=True,exist_ok=True)
  transcript.write_text(json.dumps({'type':'user','uuid':'native-msg-user-1','sessionId':sid,'cwd':project,'timestamp':'2026-10-04T00:00:00Z','message':{'role':'user','content':needle+' user native text'}})+'\n'+json.dumps({'type':'assistant','uuid':'native-msg-assistant-1','sessionId':sid,'cwd':project,'timestamp':'2026-10-04T00:00:01Z','message':{'role':'assistant','content':[{'type':'text','text':'NATIVE_ASSISTANT_TEXT_EXACT'}]}})+'\n')
  payload={'session_id':'native_hook_drift_id','transcript_path':str(transcript),'cwd':project,'hook_event_name':'SessionStart','source':'startup','model':'fake-native-model'}
  call(['native-hook','--harness',h,'--version',version],json.dumps(payload))
 elif h=='codex':
  payload={'session_id':sid,'cwd':project,'hook_event_name':'UserPromptSubmit','prompt':needle+' codex native prompt'}
  call(['native-hook','--harness',h,'--version',version],json.dumps(payload))
 else:
  plugin=root/'config/opencode/plugins/cutokyo.ts'
  mjs=root/'invoke-installed.mjs';mjs.write_text('import {Cutokyo} from '+json.dumps(plugin.as_uri())+';\nconst p=await Cutokyo({});p.event({event:'+json.dumps({'id':'review-session-created','type':'session.created','properties':{'sessionID':sid,'info':{'id':sid,'projectID':'native-project-exact','directory':project,'title':needle,'version':version,'time':{'created':1791072000000,'updated':1791072000000}}}})+'});\n')
  r=subprocess.run([node,str(mjs)],env=env,capture_output=True,text=True,timeout=10);outputs.append({'plugin_node_exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr});print(h,'node',r.returncode,r.stderr,flush=True)
 snapshot={'db_exists_before_drain':(root/'cutokyo-data/cutokyo.db').exists(),'spool_entries':[str(p) for p in (root/'cutokyo-data/spool').glob('*.jsonl')],'default_spool_exists':(root/'xdg-state/cutokyo/spool').exists()};outputs.append(snapshot);print(h,'before-drain',json.dumps(snapshot),flush=True)
 call(['drain'])
 listing=call(['sessions','list'])
 call(['sessions','search','--query',needle])
 if listing and listing.get('data'):
  for session in listing['data']:
   call(['sessions','resume',session['session_id']])
   if session.get('native_resume_id'):call(['sessions','resume',session['session_id'],'--execute'])
 (root/'outputs.json').write_text(json.dumps(outputs,indent=2))
 if (root/'harness-audit.json').exists():print(h,'AUDIT', (root/'harness-audit.json').read_text(),flush=True)
