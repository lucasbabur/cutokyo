import json, os, pathlib, subprocess, sys
root=pathlib.Path('/tmp/cutokyo-independent-onboarding-review/terminal-fixtures'+('-'+sys.argv[1] if len(sys.argv)>1 else ''))
(root/'bin').mkdir(parents=True,exist_ok=True)
(root/'home').mkdir(exist_ok=True)
terminal='''#!/usr/bin/python3
import json,os,pty,sys,time
with open(os.environ['REVIEW_TERMINAL_AUDIT'],'w') as f:json.dump(sys.argv[1:],f)
args=sys.argv[sys.argv.index('--')+1:]
mode=os.environ.get('REVIEW_TERMINAL_MODE','pty')
if mode=='exit0':sys.exit(0)
if mode=='no-tty':
 import subprocess
 sys.exit(subprocess.call(args,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL))
pid,fd=pty.fork()
if pid==0:os.execv(args[0],args)
while True:
 try:
  data=os.read(fd,1024)
  if not data:break
  os.write(1,data)
 except OSError:break
_,status=os.waitpid(pid,0)
sys.exit(os.waitstatus_to_exitcode(status))
'''
harness='''#!/usr/bin/python3
import json,os,sys,time
with open(os.environ['REVIEW_HARNESS_AUDIT'],'w') as f:json.dump({'argv':sys.argv[1:],'cwd':os.getcwd(),'stdin_tty':os.isatty(0),'stdout_tty':os.isatty(1)},f)
if os.getenv('REVIEW_HARNESS_MODE')=='exit0':sys.exit(0)
time.sleep(1)
'''
for name,source in [('kitty',terminal),('claude',harness),('codex',harness),('opencode',harness)]:
 p=root/'bin'/name;p.write_text(source);p.chmod(0o700)
env={'PATH':str(root/'bin'),'HOME':str(root/'home'),'XDG_CONFIG_HOME':str(root/'config'),'XDG_DATA_HOME':str(root/'data'),'XDG_STATE_HOME':str(root/'state'),'DISPLAY':':FAKE_ONLY','REVIEW_RECEIVER':'/home/lucas/Developer/personal/cutokyo-community/target/debug/cutokyo'}
review='/tmp/cutokyo-independent-onboarding-review/target/debug/cutokyo-independent-onboarding-review'
for name,mode,h in [('claude-pty','pty','claude_code'),('codex-pty','pty','codex'),('opencode-pty','pty','opencode'),('terminal-zero','exit0','claude_code'),('terminal-no-tty','no-tty','claude_code'),('harness-zero','pty','claude_code')]:
 runroot=root/name;runroot.mkdir(exist_ok=True)
 e=env|{'REVIEW_TERMINAL_MODE':mode,'REVIEW_TERMINAL_AUDIT':str(runroot/'terminal.json'),'REVIEW_HARNESS_AUDIT':str(runroot/'harness.json')}
 if name=='harness-zero':e['REVIEW_HARNESS_MODE']='exit0'
 r=subprocess.run([review,'resume',str(runroot),h],env=e,capture_output=True,text=True,timeout=14)
 result={'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'audit': json.loads((runroot/'harness.json').read_text()) if (runroot/'harness.json').exists() else None}
 (runroot/'result.json').write_text(json.dumps(result,indent=2));print(name,json.dumps(result),flush=True)
for name,files in [('missing-terminal',['claude']),('missing-harness',['kitty'])]:
 bindir=root/name/'bin';bindir.mkdir(parents=True,exist_ok=True)
 for file in files:
  p=bindir/file;p.write_text(terminal if file=='kitty' else harness);p.chmod(0o700)
 e=env|{'PATH':str(bindir),'REVIEW_TERMINAL_AUDIT':str(root/name/'terminal.json'),'REVIEW_HARNESS_AUDIT':str(root/name/'harness.json')}
 r=subprocess.run([review,'resume',str(root/name),'claude_code'],env=e,capture_output=True,text=True,timeout=14)
 result={'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'harness_started':(root/name/'harness.json').exists()};(root/name/'result.json').write_text(json.dumps(result,indent=2));print(name,json.dumps(result),flush=True)
