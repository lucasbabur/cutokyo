import { Cutokyo } from './run-install-only/opencode/native/opencode/plugins/cutokyo.ts';
import {mkdirSync,symlinkSync,existsSync,readdirSync} from 'node:fs';
const root='/tmp/cutokyo-independent-onboarding-review/run-install-only/opencode/private-data';
const target='/tmp/cutokyo-independent-onboarding-review/open-symlink-target';mkdirSync(target,{recursive:true,mode:0o755});
symlinkSync(target,root+'/spool');
const plugin=await Cutokyo({});plugin.event({event:{id:'review-symlink-event',type:'session.created',properties:{sessionID:'ses_symlink_exact',info:{id:'ses_symlink_exact',directory:'/tmp/synthetic-native-project',title:'PRIVATE_NATIVE_SENTINEL',time:{created:1791072000000}}}}});
console.log(JSON.stringify({intendedSpool:root+'/spool',unexpectedDestination:target,unexpectedEntries:readdirSync(target)},null,2));
