use std::{fs,path::PathBuf,os::unix::fs::PermissionsExt};
use cutokyo_core::app::{Application,CaptureSetupOperation as Op,CaptureSetupSpec,InventoryRoots};
use cutokyo_domain::Harness;
fn main()->Result<(),Box<dyn std::error::Error>>{
 let app=Application::new();let base=PathBuf::from(std::env::args().nth(1).unwrap());
 for (name,h,v) in [("claude",Harness::ClaudeCode,"2.1.278"),("codex",Harness::Codex,"0.153.4"),("opencode",Harness::OpenCode,"1.18.28")]{
  for case in ["native-bytes","native-permissions","native-removed","native-nonexec-preview","receiver-permissions","receiver-removed","receiver-nonexec-preview","native-config-symlink","data-symlink","global-config-change"] {
   if case=="global-config-change" && name!="opencode" {continue;}
   let r=base.join(name).join(case);fs::create_dir_all(&r)?;
   let roots=InventoryRoots{home:r.join("home"),claude:r.join("native/claude"),codex:r.join("native/codex"),opencode:r.join("native/opencode"),opencode_config:None,opencode_global:Some(r.join("global-opencode")),projects:vec![]};
   let paths=app.runtime_paths(Some(r.join("config.toml")),Some(r.join("data")))?;
   let receiver=r.join("receiver");let executable=r.join("native-exec");for p in [&receiver,&executable]{fs::write(p,b"#!/bin/sh\nexit 0\n")?;fs::set_permissions(p,fs::Permissions::from_mode(0o700))?;}
   let native=match h {Harness::ClaudeCode=>roots.claude.join("settings.json"),Harness::Codex=>roots.codex.join("hooks.json"),Harness::OpenCode=>roots.opencode.join("opencode.json")};fs::create_dir_all(native.parent().unwrap())?;let original=b"{  \"unmanaged\" : \"keep exact bytes\",\"hooks\":{} }\n";fs::write(&native,original)?;
   let spec=CaptureSetupSpec{roots,paths:paths.clone(),receiver:receiver.clone(),native_executable:executable.clone(),version:v.into(),harness:h};
   if case=="native-nonexec-preview" {fs::set_permissions(&executable,fs::Permissions::from_mode(0o600))?;}
   if case=="receiver-nonexec-preview" {fs::set_permissions(&receiver,fs::Permissions::from_mode(0o600))?;}
   if case=="native-config-symlink" {let target=r.join("unrelated-file");fs::write(&target,original)?;fs::remove_file(&native)?;std::os::unix::fs::symlink(target,&native)?;}
   if case=="data-symlink" {let target=r.join("unrelated-dir");fs::create_dir_all(&target)?;std::os::unix::fs::symlink(target,&paths.data_dir)?;}
   match app.preview_capture_setup(spec,Op::Install){
    Err(e)=>println!("{name} {case} preview=Err({e:?}) native_unchanged={} setup_state_exists={}",fs::read(&native)?==original,paths.data_dir.join("capture-setup").exists()),
    Ok(plan)=>{
     match case {"native-bytes"=>fs::write(&executable,b"#!/bin/sh\nexit 1\n")?,"native-permissions"=>fs::set_permissions(&executable,fs::Permissions::from_mode(0o600))?,"native-removed"=>fs::remove_file(&executable)?,"receiver-permissions"=>fs::set_permissions(&receiver,fs::Permissions::from_mode(0o600))?,"receiver-removed"=>fs::remove_file(&receiver)?,"global-config-change"=>{fs::create_dir_all(r.join("global-opencode"))?;fs::write(r.join("global-opencode/opencode.json"),b"{\"plugin\":[\"UNMANAGED_CHANGED_AFTER_PREVIEW\"]}\n")?;},_=>()}
     println!("{name} {case} execute={:?} native_unchanged={} setup_state_exists={}",app.execute_capture_setup(&plan),fs::read(&native)?==original,paths.data_dir.join("capture-setup").exists());
    }
   }
  }
 }
 Ok(())
}
