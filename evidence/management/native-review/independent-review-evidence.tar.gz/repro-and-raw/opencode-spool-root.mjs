import { Cutokyo } from './run-2/opencode/native/opencode/plugins/cutokyo.ts';
import { readdirSync,existsSync } from 'node:fs';
const plugin = await Cutokyo({serverUrl:new URL('http://127.0.0.1:1')});
plugin.event({event:{id:'review-native-event-1',type:'session.created',properties:{info:{id:'ses_native_review_1',directory:'/tmp/cutokyo-independent-onboarding-review/native-project',title:'exact native review'}}}});
const expected='/tmp/cutokyo-independent-onboarding-review/run-2/opencode/private-data/spool';
const actual='/tmp/cutokyo-independent-onboarding-review/opencode-env-home/.local/state/cutokyo/spool';
console.log(JSON.stringify({expected,expectedExists:existsSync(expected),actual,actualEntries:existsSync(actual)?readdirSync(actual):[]},null,2));
