import pathlib,subprocess,json,os
root=pathlib.Path('/tmp/cutokyo-independent-onboarding-review/claude-resume-hook');root.mkdir(exist_ok=True)
project=root/'actual-native-project';project.mkdir(exist_ok=True)
claude=root/'home/.claude';transcript=claude/'projects/native-key/exact-resumed-id.jsonl';transcript.parent.mkdir(parents=True,exist_ok=True)
transcript.write_text(json.dumps({'type':'user','uuid':'native-resume-msg-1','sessionId':'exact-resumed-id','timestamp':'2026-10-04T00:00:00Z','cwd':str(project),'message':{'role':'user','content':'NATIVE_RESUME_HOOK_NEEDLE exact content'}})+'\n')
env={'HOME':str(root/'home'),'CLAUDE_CONFIG_DIR':str(claude),'XDG_CONFIG_HOME':str(root/'config'),'XDG_DATA_HOME':str(root/'xdg-data'),'PATH':'/tmp/cutokyo-independent-onboarding-review/native-smoke-2/claude_code/bin'}
cli='/home/lucas/Developer/personal/cutokyo-community/target/debug/cutokyo';base=[cli,'--config-file',str(root/'config.toml'),'--data-dir',str(root/'data'),'--json']
payload={'session_id':'exact-resumed-id','cwd':str(project),'transcript_path':str(transcript),'hook_event_name':'SessionStart','source':'resume','model':'synthetic-no-provider'}
for args,stdin in [(['native-hook','--harness','claude_code','--version','2.1.278'],json.dumps(payload)),(['drain'],None),(['sessions','list'],None),(['sessions','search','--query','NATIVE_RESUME_HOOK_NEEDLE'],None),(['sessions','resume','exact-resumed-id'],None)]:
 r=subprocess.run(base+args,env=env,input=stdin,capture_output=True,text=True,timeout=15);print(json.dumps({'command':base+args,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr}),flush=True)
