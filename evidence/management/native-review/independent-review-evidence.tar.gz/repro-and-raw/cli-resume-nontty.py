import pathlib,os,subprocess,json
root=pathlib.Path('/tmp/cutokyo-independent-onboarding-review/cli-resume-nontty');(root/'home').mkdir(parents=True,exist_ok=True);(root/'bin').mkdir(exist_ok=True)
p=root/'bin'/'claude';p.write_text('#!/usr/bin/python3\nimport os,json,sys\nopen(os.environ["AUDIT"],"w").write(json.dumps({"argv":sys.argv[1:],"ttyin":os.isatty(0),"ttyout":os.isatty(1)}))\n');p.chmod(0o700)
env={'PATH':str(root/'bin'),'HOME':str(root/'home'),'XDG_CONFIG_HOME':str(root/'config'),'XDG_DATA_HOME':str(root/'data'),'XDG_STATE_HOME':str(root/'state'),'AUDIT':str(root/'audit.json')}
(root/'audit.json').unlink(missing_ok=True)
cli='/home/lucas/Developer/personal/cutokyo-community/target/debug/cutokyo'
base=[cli,'--config-file',str(root/'config.toml'),'--data-dir',str(root/'cutokyo'),'--json']
obs={'observation_id':'obs:review:cli-nontty','harness':'claude_code','observed_at':'2026-10-04T00:00:00Z','kind':'review.synthetic','source':{'channel':'hook_or_plugin','captured_at':'2026-10-04T00:00:00Z','native':{'event_id':'review-native-event','resume_id':'review-native-exact','session_key':'session:review:cli-nontty','sequence':1},'parser_version':'review-synthetic-v1','confidence':'observed','coverage':{'state':'partial','scope':'synthetic CLI launch-only repro','gaps':['not native capture proof']}},'payload':{'session_id':'session:review:cli-nontty'}}
r=subprocess.run(base+['hook'],env=env,input=json.dumps(obs),capture_output=True,text=True); print(json.dumps({'command':base+['hook'],'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr}),flush=True)
r=subprocess.run(base+['drain'],env=env,stdin=subprocess.DEVNULL,capture_output=True,text=True); print(json.dumps({'command':base+['drain'],'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr}),flush=True)
for args in [['sessions','list'],['sessions','resume','session:review:cli-nontty','--execute']]:
 r=subprocess.run(base+args,env=env,stdin=subprocess.DEVNULL,capture_output=True,text=True)
 print(json.dumps({'command':base+args,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr}),flush=True)
 if args[1]=='search':
  j=json.loads(r.stdout);(root/'search.json').write_text(json.dumps(j,indent=2))
if (root/'audit.json').exists():print((root/'audit.json').read_text())
