import {
  act,
  fireEvent,
  render,
  screen,
  waitFor,
  within,
} from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import type { ReactNode } from "react";
import { describe, expect, it, vi } from "vitest";

import { CommandProvider } from "../commands/context.js";
import { AnnouncementProvider } from "../components/Announcer.js";
import { AppShell } from "../components/AppShell.js";
import type { CommandClient } from "../contracts.js";
import { createBrowserFixtureClient } from "../fixtures/browserAdapter.js";
import { DashboardPage } from "./DashboardPage.js";
import { HealthPage } from "./HealthPage.js";
import { OnboardingPage } from "./OnboardingPage.js";
import { SessionsPage } from "./SessionsPage.js";

function renderWithClient(client: CommandClient, node: ReactNode) {
  return render(
    <CommandProvider client={client}>
      <AnnouncementProvider>{node}</AnnouncementProvider>
    </CommandProvider>,
  );
}

describe("desktop route components", () => {
  it("discloses the exact bounded scope of overview totals", async () => {
    const base = createBrowserFixtureClient("populated-dashboard");
    const dashboard = await base.getDashboard();
    const notice =
      "Overview totals cover the latest 500 of 503 stored sessions. Sessions search can reach all retained history.";
    renderWithClient(
      {
        ...base,
        getDashboard: async () => ({
          ...dashboard,
          meta: { ...dashboard.meta, freshness: "partial", notices: [notice] },
        }),
      },
      <DashboardPage />,
    );
    expect(
      (await screen.findByLabelText("partial data notice")).textContent,
    ).toContain(notice);
  });

  it("moves focus to a route heading that renders after loading", async () => {
    const client = createBrowserFixtureClient("health-degraded");
    const bootstrap = await client.getBootstrap();
    const shell = (path: "/dashboard" | "/health") => (
      <CommandProvider client={client}>
        <AnnouncementProvider>
          <AppShell bootstrap={bootstrap} currentPath={path}>
            {path === "/health" ? <HealthPage /> : <DashboardPage />}
          </AppShell>
        </AnnouncementProvider>
      </CommandProvider>
    );
    const view = render(shell("/dashboard"));
    await screen.findByRole("heading", { name: "Overview" });
    expect(document.activeElement).toBe(document.body);
    view.rerender(shell("/health"));
    const heading = await screen.findByRole("heading", {
      name: "System health",
    });
    await waitFor(() => expect(document.activeElement).toBe(heading));
  });

  it("renders chart totals, raw values, uncertainty, and absent context consistently", async () => {
    renderWithClient(
      createBrowserFixtureClient("populated-dashboard"),
      <DashboardPage />,
    );
    await screen.findByRole("heading", { name: "Overview" });
    const table = screen.getByRole("table", {
      name: "Raw values used by the token usage chart",
    });
    expect(within(table).getByText("184,200")).toBeTruthy();
    expect(within(table).getByText("42,810")).toBeTruthy();
    expect(within(table).getByText("227,010")).toBeTruthy();
    expect(screen.getByText("Absent, not zero")).toBeTruthy();
    const quota = screen.getByRole("meter", {
      name: "Claude 5-hour window remaining",
    });
    expect(quota.getAttribute("aria-valuenow")).toBe("72");
    expect(screen.getByText("Remaining amount unknown")).toBeTruthy();
  });

  it("shows a useful history-empty state instead of fake zero analytics", async () => {
    renderWithClient(
      createBrowserFixtureClient("empty-history"),
      <SessionsPage sessionId={null} />,
    );
    await screen.findByRole("heading", { name: "Sessions" });
    expect(await screen.findByText("History is empty—not zero")).toBeTruthy();
    expect(
      screen.getByRole("link", { name: "Review capture setup" }),
    ).toBeTruthy();
  });

  it("searches one session and exposes its coverage label", async () => {
    const user = userEvent.setup();
    renderWithClient(
      createBrowserFixtureClient("search-resume"),
      <SessionsPage sessionId={null} />,
    );
    const search = await screen.findByRole("searchbox", {
      name: "Search session content",
    });
    await user.type(search, "JEV exact resume needle 73A9");
    await waitFor(() => {
      expect(screen.getByText("1 session")).toBeTruthy();
    });
    expect(
      screen.getByRole("link", { name: "Reconcile usage capture" }),
    ).toBeTruthy();
    expect(screen.getByText("complete")).toBeTruthy();
  });

  it("moves focus to content search with the advertised keyboard shortcut", async () => {
    const user = userEvent.setup();
    renderWithClient(
      createBrowserFixtureClient("search-resume"),
      <SessionsPage sessionId={null} />,
    );
    const search = await screen.findByRole("searchbox", {
      name: "Search session content",
    });
    const harness = screen.getByRole("combobox", { name: "Harness" });
    harness.focus();
    await user.keyboard("{Control>}k{/Control}");
    expect(document.activeElement).toBe(search);
    expect(search.getAttribute("aria-keyshortcuts")).toBe("Control+K Meta+K");
  });

  it("confirms the exact native target and restores focus after cancel", async () => {
    const user = userEvent.setup();
    renderWithClient(
      createBrowserFixtureClient("search-resume"),
      <SessionsPage sessionId="session-claude-73A9" />,
    );
    const resume = await screen.findByRole("button", { name: "Resume" });
    resume.focus();
    await user.click(resume);
    const dialog = await screen.findByRole("dialog", {
      name: "Resume this exact native session?",
    });
    expect(await within(dialog).findByText("claude-jev-73A9")).toBeTruthy();
    await user.click(within(dialog).getByRole("button", { name: "Cancel" }));
    expect(document.activeElement).toBe(resume);
  });

  it("traps keyboard focus inside destructive confirmation and closes on Escape", async () => {
    const user = userEvent.setup();
    renderWithClient(
      createBrowserFixtureClient("search-resume"),
      <SessionsPage sessionId="session-claude-73A9" />,
    );
    const trigger = await screen.findByRole("button", {
      name: "Delete session",
    });
    trigger.focus();
    await user.click(trigger);
    const dialog = await screen.findByRole("dialog", {
      name: "Delete only this session?",
    });
    const cancel = within(dialog).getByRole("button", { name: "Cancel" });
    const confirm = within(dialog).getByRole("button", {
      name: "Delete selected session",
    });
    await waitFor(() => {
      expect((confirm as HTMLButtonElement).disabled).toBe(false);
    });
    confirm.focus();
    await user.tab();
    expect(document.activeElement).toBe(
      within(dialog).getByRole("button", { name: "Close dialog" }),
    );
    await user.keyboard("{Escape}");
    expect(screen.queryByRole("dialog")).toBeNull();
    expect(document.activeElement).toBe(trigger);
    expect(cancel).not.toBe(document.activeElement);
  });

  it("previews and cancels capture without applying native changes", async () => {
    const base = createBrowserFixtureClient("onboarding-empty");
    const apply = vi.fn(base.applyCaptureSetup);
    const user = userEvent.setup();
    renderWithClient(
      { ...base, applyCaptureSetup: apply },
      <OnboardingPage mode="onboarding" onComplete={() => undefined} />,
    );
    await user.click(
      await screen.findByRole("button", {
        name: "Preview Claude Code install",
      }),
    );
    expect(await screen.findByLabelText("Capture setup preview")).toBeTruthy();
    expect(apply).not.toHaveBeenCalled();
    expect(
      (
        screen.getByRole("button", {
          name: "Confirm install for Claude Code",
        }) as HTMLButtonElement
      ).disabled,
    ).toBe(true);
    await user.click(screen.getByRole("button", { name: "Cancel preview" }));
    expect(screen.queryByLabelText("Capture setup preview")).toBeNull();
    expect(apply).not.toHaveBeenCalled();
    expect((await base.getBootstrap()).onboardingComplete).toBe(false);
  });

  it("confirms one pending setup token once and requires selected verified capture", async () => {
    const base = createBrowserFixtureClient("onboarding-empty");
    let release: (() => void) | undefined;
    const pending = new Promise<void>((resolve) => {
      release = resolve;
    });
    const apply = vi.fn(async (token: string) => {
      await pending;
      return base.applyCaptureSetup(token);
    });
    const complete = vi.fn(base.completeOnboarding);
    const user = userEvent.setup();
    renderWithClient(
      { ...base, applyCaptureSetup: apply, completeOnboarding: complete },
      <OnboardingPage mode="onboarding" onComplete={() => undefined} />,
    );
    await user.click(
      await screen.findByRole("checkbox", { name: /I understand/ }),
    );
    await user.click(screen.getByRole("checkbox", { name: /Claude Code/ }));
    expect(
      (
        screen.getByRole("button", {
          name: "Finish with verified capture",
        }) as HTMLButtonElement
      ).disabled,
    ).toBe(true);
    await user.click(
      screen.getByRole("button", { name: "Preview Claude Code install" }),
    );
    const confirm = await screen.findByRole("button", {
      name: "Confirm install for Claude Code",
    });
    act(() => {
      fireEvent.click(confirm);
      fireEvent.click(confirm);
    });
    expect(apply).toHaveBeenCalledTimes(1);
    expect(complete).not.toHaveBeenCalled();
    await act(async () => {
      release?.();
      await pending;
    });
    await waitFor(() => {
      expect(
        (
          screen.getByRole("button", {
            name: "Finish with verified capture",
          }) as HTMLButtonElement
        ).disabled,
      ).toBe(false);
    });
    expect(
      screen.getByText("Configuration verified. Live capture unknown."),
    ).toBeTruthy();
    await user.click(
      screen.getByRole("button", { name: "Finish with verified capture" }),
    );
    await waitFor(() => {
      expect(complete).toHaveBeenCalledTimes(1);
    });
    expect(complete).toHaveBeenCalledWith({
      mode: "install",
      harnesses: ["claude_code"],
      acknowledgedPlaintextStorage: true,
      proxyEnabled: false,
      analysisEgressEnabled: false,
    });
  });

  it("keeps unavailable recovery inline and permits an explicit retry", async () => {
    const base = createBrowserFixtureClient("onboarding-empty");
    const preview = vi
      .fn(base.previewCaptureSetup)
      .mockRejectedValueOnce(
        new Error(
          "Native harness missing. Install the supported version or browse without installing.",
        ),
      );
    const user = userEvent.setup();
    renderWithClient(
      { ...base, previewCaptureSetup: preview },
      <OnboardingPage mode="onboarding" onComplete={() => undefined} />,
    );
    await user.click(
      await screen.findByRole("button", { name: "Recover Codex" }),
    );
    expect((await screen.findByRole("alert")).textContent).toContain(
      "Native harness missing",
    );
    await user.click(screen.getByRole("button", { name: "Recover Codex" }));
    expect(await screen.findByLabelText("Capture setup preview")).toBeTruthy();
    expect(preview).toHaveBeenNthCalledWith(2, "codex", "recover");
  });

  it("requires the plaintext boundary and keeps optional egress off during onboarding", async () => {
    const client = createBrowserFixtureClient("onboarding-empty");
    const user = userEvent.setup();
    renderWithClient(
      client,
      <OnboardingPage mode="onboarding" onComplete={() => undefined} />,
    );
    const complete = await screen.findByRole("button", {
      name: /Browse without installing/,
    });
    expect((complete as HTMLButtonElement).disabled).toBe(true);
    await user.click(screen.getByRole("checkbox", { name: /I understand/ }));
    expect((complete as HTMLButtonElement).disabled).toBe(false);
    await user.click(complete);
    await waitFor(async () => {
      expect((await client.getBootstrap()).onboardingComplete).toBe(true);
    });
    expect((await client.getProxyStatus()).proxyEnabled).toBe(false);
  });

  it("offers a retry for command-boundary errors", async () => {
    const base = createBrowserFixtureClient("populated-dashboard");
    const client: CommandClient = {
      ...base,
      getDashboard: async () => {
        throw new Error("Synthetic dashboard failure");
      },
    };
    renderWithClient(client, <DashboardPage />);
    const alert = await screen.findByRole("alert");
    expect(alert.textContent).toContain("Synthetic dashboard failure");
    expect(screen.getByText("Synthetic dashboard failure")).toBeTruthy();
    expect(screen.getByRole("button", { name: "Retry" })).toBeTruthy();
  });
});
