import {
  act,
  fireEvent,
  render,
  screen,
  waitFor,
  within,
} from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";

import { App } from "./App.js";
import { CommandProvider } from "./commands/context.js";
import { AnnouncementProvider } from "./components/Announcer.js";
import { createBrowserFixtureClient } from "./fixtures/browserAdapter.js";

describe("application ownership state", () => {
  it("lets a completed user with history cancel and remove native capture through Settings without resetting preferences", async () => {
    globalThis.location.hash = "#/settings";
    const base = createBrowserFixtureClient("populated-dashboard");
    const installed = await base.previewCaptureSetup("claude_code", "install");
    await base.applyCaptureSetup(installed.previewToken);
    const settings = await base.getSettings();
    const selectionIntent = await base.getOnboarding();
    expect(selectionIntent.complete).toBe(true);
    const history = await base.getDashboard();
    expect(history.sessions.length).toBeGreaterThan(0);
    const complete = vi.fn(base.completeOnboarding);
    const patch = vi.fn(base.patchSettings);
    const preferences = vi.fn(base.patchDesktopPreferences);
    const apply = vi.fn(base.applyCaptureSetup);
    const user = userEvent.setup();
    render(
      <CommandProvider
        client={{
          ...base,
          completeOnboarding: complete,
          patchSettings: patch,
          patchDesktopPreferences: preferences,
          applyCaptureSetup: apply,
        }}
      >
        <AnnouncementProvider>
          <App />
        </AnnouncementProvider>
      </CommandProvider>,
    );
    await user.click(
      await screen.findByRole("link", { name: "Manage native capture" }),
    );
    await screen.findByRole("heading", { name: "Manage native capture" });
    expect(
      screen.queryByRole("button", { name: "Finish with verified capture" }),
    ).toBeNull();
    expect(
      screen.queryByRole("button", { name: "Browse without installing" }),
    ).toBeNull();
    expect(screen.queryByRole("checkbox", { name: /Claude Code/ })).toBeNull();
    await user.click(
      screen.getByRole("button", { name: "Preview Claude Code removal" }),
    );
    const confirm = await screen.findByRole("button", {
      name: "Confirm uninstall for Claude Code",
    });
    expect((confirm as HTMLButtonElement).disabled).toBe(true);
    expect(
      within(screen.getByLabelText("Capture setup preview")).getByText(
        /Already-running harness callbacks may remain loaded until that harness restarts; live capture remains unknown\./,
      ),
    ).toBeTruthy();
    expect(screen.queryByText(/Removed capture is not active/)).toBeNull();
    expect(apply).not.toHaveBeenCalled();
    await user.click(screen.getByRole("button", { name: "Cancel preview" }));
    expect(screen.queryByLabelText("Capture setup preview")).toBeNull();
    expect(apply).not.toHaveBeenCalled();
    await user.click(screen.getByRole("checkbox", { name: /I understand/ }));
    await user.click(
      screen.getByRole("button", { name: "Preview Claude Code removal" }),
    );
    await user.click(
      await screen.findByRole("button", {
        name: "Confirm uninstall for Claude Code",
      }),
    );
    await waitFor(() =>
      expect(screen.queryByLabelText("Capture setup preview")).toBeNull(),
    );
    expect(apply).toHaveBeenCalledTimes(1);
    const verify = await base.previewCaptureSetup("claude_code", "install");
    expect(verify.verified).toBe(false);
    expect(
      within(
        screen.getByRole("group", {
          name: "Claude Code capture configuration",
        }),
      ).getByText("Configuration not verified. Live capture unknown."),
    ).toBeTruthy();
    expect(
      screen.getByText(
        /Removal changes configuration only\. Already-running harness callbacks may remain loaded until that harness restarts; live capture remains unknown\./,
      ),
    ).toBeTruthy();
    expect(screen.queryByText(/Removed capture is not active/)).toBeNull();
    expect(await base.getOnboarding()).toEqual(selectionIntent);
    expect(await base.getSettings()).toEqual(settings);
    expect(await base.getDashboard()).toEqual(history);
    expect((await base.getBootstrap()).onboardingComplete).toBe(true);
    expect(complete).not.toHaveBeenCalled();
    expect(patch).not.toHaveBeenCalled();
    expect(preferences).not.toHaveBeenCalled();
    await user.click(
      screen.getByRole("button", { name: "Return to Settings" }),
    );
    await screen.findByRole("heading", { name: "Settings" });
    expect(globalThis.location.hash).toBe("#/settings");
  });

  it("keeps completed-user removal pending once, reports failure, and permits recovery without a stale verification claim", async () => {
    globalThis.location.hash = "#/onboarding";
    const base = createBrowserFixtureClient("populated-dashboard");
    const installed = await base.previewCaptureSetup("claude_code", "install");
    await base.applyCaptureSetup(installed.previewToken);
    let release: (() => void) | undefined;
    const pending = new Promise<void>((resolve) => {
      release = resolve;
    });
    const apply = vi.fn(async (_token: string) => {
      await pending;
      throw new Error(
        "Native configuration changed. Preview again before removing capture.",
      );
    });
    const complete = vi.fn(base.completeOnboarding);
    const user = userEvent.setup();
    render(
      <CommandProvider
        client={{
          ...base,
          applyCaptureSetup: apply,
          completeOnboarding: complete,
        }}
      >
        <AnnouncementProvider>
          <App />
        </AnnouncementProvider>
      </CommandProvider>,
    );
    await screen.findByRole("heading", { name: "Manage native capture" });
    await user.click(screen.getByRole("checkbox", { name: /I understand/ }));
    await user.click(
      screen.getByRole("button", { name: "Preview Claude Code removal" }),
    );
    const confirm = await screen.findByRole("button", {
      name: "Confirm uninstall for Claude Code",
    });
    act(() => {
      fireEvent.click(confirm);
      fireEvent.click(confirm);
    });
    expect(apply).toHaveBeenCalledTimes(1);
    expect(
      (
        screen.getByRole("button", {
          name: "Return to Settings",
        }) as HTMLButtonElement
      ).disabled,
    ).toBe(true);
    expect(
      (
        screen.getByRole("button", {
          name: "Recover Codex",
        }) as HTMLButtonElement
      ).disabled,
    ).toBe(true);
    await act(async () => {
      release?.();
      await pending;
    });
    expect((await screen.findByRole("alert")).textContent).toContain(
      "Native configuration changed",
    );
    expect(screen.queryByLabelText("Capture setup preview")).toBeNull();
    expect(
      screen.queryByText("Configuration verified. Live capture unknown."),
    ).toBeNull();
    await user.click(
      screen.getByRole("button", { name: "Recover Claude Code" }),
    );
    await screen.findByRole("button", {
      name: "Confirm recover for Claude Code",
    });
    expect(screen.queryByRole("alert")).toBeNull();
    expect(complete).not.toHaveBeenCalled();
    expect((await base.getBootstrap()).onboardingComplete).toBe(true);
  });
  it("reconciles the sidebar after writer recovery without clearing other failures", async () => {
    globalThis.location.hash = "#/health";
    const client = createBrowserFixtureClient("health-degraded");
    render(
      <CommandProvider client={client}>
        <AnnouncementProvider>
          <App />
        </AnnouncementProvider>
      </CommandProvider>,
    );
    await screen.findByRole("heading", { name: "System health" });
    expect(screen.getByText("Read-only view")).toBeTruthy();
    await userEvent.click(
      screen.getByRole("button", { name: "Retry writer lock" }),
    );
    await waitFor(() =>
      expect(screen.queryByText("Read-only view")).toBeNull(),
    );
    const health = await client.getHealth();
    expect(
      health.dimensions.find((entry) => entry.id === "writer_lock")?.state,
    ).toBe("healthy");
    expect(health.dimensions.some((entry) => entry.state === "degraded")).toBe(
      true,
    );
    expect(screen.getByRole("heading", { name: "System health" })).toBeTruthy();
  });
});
