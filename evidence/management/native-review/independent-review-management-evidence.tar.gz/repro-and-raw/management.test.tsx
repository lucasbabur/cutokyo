import { render, screen, waitFor, within, cleanup } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { afterEach, expect, test, vi } from 'vitest';
import { App } from '/home/lucas/Developer/personal/cutokyo-community/ui/src/App.tsx';
import { CommandProvider } from '/home/lucas/Developer/personal/cutokyo-community/ui/src/commands/context.tsx';
import { AnnouncementProvider } from '/home/lucas/Developer/personal/cutokyo-community/ui/src/components/Announcer.tsx';
import { createBrowserFixtureClient } from '/home/lucas/Developer/personal/cutokyo-community/ui/src/fixtures/browserAdapter.ts';
afterEach(()=>{cleanup();globalThis.location.hash='';});
Object.defineProperty(globalThis,'matchMedia',{configurable:true,value:(query:string)=>({matches:false,media:query,addEventListener(){},removeEventListener(){}})});
for(const [harness,name] of [['claude_code','Claude Code'],['codex','Codex'],['opencode','OpenCode']] as const){
 test(`completed populated user manages ${name} from persistent Settings, cancellation is read-only and removal/recovery/install preserve preferences`,async()=>{
  globalThis.location.hash='#/settings';
  const base=createBrowserFixtureClient('populated-dashboard');
  const seed=await base.previewCaptureSetup(harness,'install');await base.applyCaptureSetup(seed.previewToken);
  const onboarding=await base.getOnboarding();const settings=await base.getSettings();const history=await base.getDashboard();
  expect(onboarding.complete).toBe(true);expect(history.sessions.length).toBeGreaterThan(0);
  const completeOnboarding=vi.fn(base.completeOnboarding);const patchSettings=vi.fn(base.patchSettings);const patchDesktopPreferences=vi.fn(base.patchDesktopPreferences);
  const previewCaptureSetup=vi.fn(base.previewCaptureSetup);const applyCaptureSetup=vi.fn(base.applyCaptureSetup);
  render(<CommandProvider client={{...base,completeOnboarding,patchSettings,patchDesktopPreferences,previewCaptureSetup,applyCaptureSetup}}><AnnouncementProvider><App/></AnnouncementProvider></CommandProvider>);
  const user=userEvent.setup();await user.click(await screen.findByRole('link',{name:'Manage native capture'}));
  await screen.findByRole('heading',{name:'Manage native capture'});
  expect(applyCaptureSetup).not.toHaveBeenCalled();expect(previewCaptureSetup).not.toHaveBeenCalled();
  expect(screen.queryByText(/Removed capture is not active/)).toBeNull();
  expect(screen.getByText(/Selected harness preferences are unchanged\. Removal changes configuration only\. Already-running harness callbacks may remain loaded until that harness restarts; live capture remains unknown\./)).toBeTruthy();
  expect(screen.queryByRole('button',{name:'Browse without installing'})).toBeNull();expect(screen.queryByRole('button',{name:'Finish with verified capture'})).toBeNull();
  expect(screen.queryByRole('checkbox',{name:new RegExp(name)})).toBeNull();
  await user.click(screen.getByRole('button',{name:`Preview ${name} removal`}));
  const unacknowledged=await screen.findByRole('button',{name:`Confirm uninstall for ${name}`});expect((unacknowledged as HTMLButtonElement).disabled).toBe(true);
  expect(within(screen.getByLabelText('Capture setup preview')).getByText('Removal changes configuration only. Already-running harness callbacks may remain loaded until that harness restarts; live capture remains unknown.')).toBeTruthy();
  const cancelPlan=previewCaptureSetup.mock.results[0];expect(cancelPlan.type).toBe('return');
  await user.click(screen.getByRole('button',{name:'Cancel preview'}));expect(applyCaptureSetup).not.toHaveBeenCalled();
  await user.click(screen.getByRole('checkbox',{name:/I understand/}));
  for(const [operation,button,verified] of [['uninstall',`Preview ${name} removal`,false],['recover',`Recover ${name}`,false],['install',`Preview ${name} install`,true]] as const){
   await user.click(screen.getByRole('button',{name:button}));
   await screen.findByRole('button',{name:`Confirm ${operation} for ${name}`});
   const plan=await previewCaptureSetup.mock.results.at(-1)!.value;
   expect(plan.harness).toBe(harness);expect(plan.operation).toBe(operation);
   await user.click(screen.getByRole('button',{name:`Confirm ${operation} for ${name}`}));
   await waitFor(()=>expect(screen.queryByLabelText('Capture setup preview')).toBeNull());
   expect(applyCaptureSetup).toHaveBeenLastCalledWith(plan.previewToken);
   expect(within(screen.getByRole('group',{name:`${name} capture configuration`})).getByText(verified?'Configuration verified. Live capture unknown.':'Configuration not verified. Live capture unknown.')).toBeTruthy();
  }
  expect(applyCaptureSetup).toHaveBeenCalledTimes(3);
  expect(await base.getOnboarding()).toEqual(onboarding);expect(await base.getSettings()).toEqual(settings);expect(await base.getDashboard()).toEqual(history);
  expect(completeOnboarding).not.toHaveBeenCalled();expect(patchSettings).not.toHaveBeenCalled();expect(patchDesktopPreferences).not.toHaveBeenCalled();
  await user.click(screen.getByRole('button',{name:'Return to Settings'}));await screen.findByRole('heading',{name:'Settings'});
  expect(globalThis.location.hash).toBe('#/settings');expect((await base.getBootstrap()).onboardingComplete).toBe(true);
 });
}
