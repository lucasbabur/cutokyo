import { render, screen, waitFor, cleanup } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { afterEach, expect, test, vi } from 'vitest';
import { CommandProvider } from '/home/lucas/Developer/personal/cutokyo-community/ui/src/commands/context.tsx';
import { AnnouncementProvider } from '/home/lucas/Developer/personal/cutokyo-community/ui/src/components/Announcer.tsx';
import { OnboardingPage } from '/home/lucas/Developer/personal/cutokyo-community/ui/src/pages/OnboardingPage.tsx';
import { createBrowserFixtureClient } from '/home/lucas/Developer/personal/cutokyo-community/ui/src/fixtures/browserAdapter.ts';
afterEach(cleanup);
function mock(){
 const base=createBrowserFixtureClient('onboarding-empty');
 const previewCaptureSetup=vi.fn(async()=>({previewToken:'EXACT_REVIEW_TOKEN',harness:'claude_code',operation:'install',version:'2.1.278',targets:['owned native settings'],actions:['Persist intent','Install hook'],issues:[],verified:false,recoveryPending:false,disclosure:'Live capture unknown'}));
 const applyCaptureSetup=vi.fn(async()=>({harness:'claude_code',operation:'install',changed:true,verified:true,issues:[],message:'Configuration verified. Live capture unknown.'}));
 const completeOnboarding=vi.fn(base.completeOnboarding);
 const client={...base,previewCaptureSetup,applyCaptureSetup,completeOnboarding};
 render(<CommandProvider client={client as any}><AnnouncementProvider><OnboardingPage mode="onboarding" onComplete={()=>undefined}/></AnnouncementProvider></CommandProvider>);
 return {client,previewCaptureSetup,applyCaptureSetup,completeOnboarding,user:userEvent.setup()};
}
test('browse completion sends empty harness selection and invokes no preview/apply',async()=>{
 const m=mock();await screen.findByRole('heading',{name:'Preview and install native capture'});
 await m.user.click(screen.getByRole('checkbox',{name:/Claude Code/}));
 await m.user.click(screen.getByRole('checkbox',{name:/I understand/}));
 await m.user.click(screen.getByRole('button',{name:'Browse without installing'}));
 await waitFor(()=>expect(m.completeOnboarding).toHaveBeenCalledWith({mode:'browse',harnesses:[],acknowledgedPlaintextStorage:true,proxyEnabled:false,analysisEgressEnabled:false}));
 expect(m.previewCaptureSetup).not.toHaveBeenCalled();expect(m.applyCaptureSetup).not.toHaveBeenCalled();
});
test('preview is read only and confirmation binds token; finish waits verification',async()=>{
 const m=mock();await screen.findByRole('heading',{name:'Preview and install native capture'});
 const finish=screen.getByRole('button',{name:/Finish with verified capture/});
 await m.user.click(screen.getByRole('checkbox',{name:/Claude Code/}));
 expect((finish as HTMLButtonElement).disabled).toBe(true);
 await m.user.click(screen.getByRole('button',{name:'Preview Claude Code install'}));
 await screen.findByRole('heading',{name:'Claude Code install preview'});
 expect(m.previewCaptureSetup).toHaveBeenCalledWith('claude_code','install');expect(m.applyCaptureSetup).not.toHaveBeenCalled();
 const confirm=screen.getByRole('button',{name:'Confirm install for Claude Code'});expect((confirm as HTMLButtonElement).disabled).toBe(true);
 await m.user.click(screen.getByRole('checkbox',{name:/I understand/}));
 await m.user.click(confirm);await waitFor(()=>expect(m.applyCaptureSetup).toHaveBeenCalledWith('EXACT_REVIEW_TOKEN'));
 await waitFor(()=>expect((finish as HTMLButtonElement).disabled).toBe(false));
 await m.user.click(finish);await waitFor(()=>expect(m.completeOnboarding).toHaveBeenCalledWith({mode:'install',harnesses:['claude_code'],acknowledgedPlaintextStorage:true,proxyEnabled:false,analysisEgressEnabled:false}));
});
