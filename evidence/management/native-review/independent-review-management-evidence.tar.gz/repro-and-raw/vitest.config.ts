import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';
export default defineConfig({root:'/tmp/cutokyo-independent-onboarding-review',plugins:[react()],test:{environment:'jsdom',include:['onboarding.test.tsx','management.test.tsx']}});
