from pathlib import Path
import subprocess,json,sys
base=Path('/tmp/cutokyo-independent-onboarding-review'); root=base/('management-loaded-plugin'+('-'+sys.argv[1] if len(sys.argv)>1 else ''));root.mkdir();(root/'bin').mkdir()
cli='/home/lucas/Developer/personal/cutokyo-community/target/debug/cutokyo'
node=subprocess.check_output(['node','-p','process.execPath'],text=True).strip()
fake=root/'bin/opencode';fake.write_text('#!/usr/bin/python3\nprint("1.18.28")\n');fake.chmod(0o700);(root/'bin/cutokyo').symlink_to(cli)
env={'HOME':str(root/'home'),'XDG_CONFIG_HOME':str(root/'config'),'XDG_DATA_HOME':str(root/'xdg-data'),'PATH':str(root/'bin')}
args=['--config-file',str(root/'config.toml'),'--data-dir',str(root/'data'),'--json','capture-setup','--harness','opencode']
install=subprocess.run([cli,*args],env=env,text=True,capture_output=True,timeout=20,check=True)
print(json.dumps({'install':json.loads(install.stdout)}),flush=True)
plugin=root/'config/opencode/plugins/cutokyo.ts'
event={'id':'loaded-after-uninstall','type':'session.created','properties':{'sessionID':'ses_loaded_review','info':{'id':'ses_loaded_review','directory':str(root/'project'),'title':'Existing native process callback survives config removal','version':'1.18.28','time':{'created':1791072000000,'updated':1791072000000}}}}
script=root/'loaded.mjs';script.write_text('import {Cutokyo} from '+json.dumps(plugin.as_uri())+';import {spawnSync} from "node:child_process";import {existsSync,readdirSync} from "node:fs";const loaded=await Cutokyo({});const removed=spawnSync('+json.dumps(cli)+','+json.dumps(args+['--uninstall'])+',{encoding:"utf8"});console.log(JSON.stringify({uninstall_exit:removed.status,uninstall_stdout:removed.stdout,uninstall_stderr:removed.stderr,plugin_file_exists:existsSync('+json.dumps(str(plugin))+')}));loaded.event({event:'+json.dumps(event)+'});console.log(JSON.stringify({callback_after_removal:true,spool_entries:readdirSync('+json.dumps(str(root/'data/spool'))+').filter(x=>x.endsWith(".jsonl"))}));')
result=subprocess.run([node,str(script)],env=env,text=True,capture_output=True,timeout=25)
print(json.dumps({'node_exit':result.returncode,'stdout':result.stdout,'stderr':result.stderr,'database_exists':(root/'data/cutokyo.db').exists()}),flush=True)
assert result.returncode==0 and not result.stderr and not (root/'data/cutokyo.db').exists()
lines=[json.loads(line) for line in result.stdout.splitlines()]
assert lines[0]['uninstall_exit']==0 and lines[0]['plugin_file_exists'] is False
assert json.loads(lines[0]['uninstall_stdout'])['data']['verified'] is False
assert lines[1]['callback_after_removal'] is True and len(lines[1]['spool_entries'])==1
