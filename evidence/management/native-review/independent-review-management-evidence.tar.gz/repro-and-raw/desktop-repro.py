import pathlib,subprocess,json,shutil,sys
root=pathlib.Path('/tmp/cutokyo-independent-onboarding-review/desktop-'+sys.argv[1]);root.mkdir(exist_ok=True);(root/'bin').mkdir(exist_ok=True);cli='/home/lucas/Developer/personal/cutokyo-community/target/debug/cutokyo';(root/'bin/cutokyo').symlink_to(cli)
for name,version in [('claude','2.1.278'),('codex','0.153.4'),('opencode','1.18.28')]:
 p=root/'bin'/name;p.write_text('#!/usr/bin/python3\nimport sys\nif sys.argv[1:]==["--version"]:print("'+version+'");sys.exit(0)\nsys.exit(80)\n');p.chmod(0o700)
env={'HOME':str(root/'home'),'CLAUDE_CONFIG_DIR':str(root/'home/.claude'),'CODEX_HOME':str(root/'home/.codex'),'XDG_CONFIG_HOME':str(root/'xdg-config'),'XDG_DATA_HOME':str(root/'xdg-data'),'PATH':str(root/'bin')}
try:
 r=subprocess.run(['/tmp/cutokyo-independent-onboarding-review/target/debug/desktop',str(root),*sys.argv[2:]],env=env,capture_output=True,text=True,timeout=45);print(json.dumps({'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr}),flush=True)
except subprocess.TimeoutExpired as e:
 print(json.dumps({'timeout_seconds':45,'stdout':(e.stdout or b'').decode() if isinstance(e.stdout,bytes) else e.stdout,'stderr':(e.stderr or b'').decode() if isinstance(e.stderr,bytes) else e.stderr}),flush=True)
 raise
